import SwiftUI
import WidgetKit

struct PetEntry: TimelineEntry { let date: Date }
struct PetProvider: TimelineProvider {
    func placeholder(in context: Context) -> PetEntry { PetEntry(date: Date()) }
    func getSnapshot(in context: Context, completion: @escaping (PetEntry) -> Void) { completion(PetEntry(date: Date())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<PetEntry>) -> Void) {
        let now = Date()
        let entries = (0..<8).map { PetEntry(date: now.addingTimeInterval(Double($0) * 3600)) }
        completion(Timeline(entries: entries, policy: .atEnd))
    }
}
struct PetWidgetView: View {
    let entry: PetEntry
    @Environment(\.widgetFamily) private var family
    private var hour: Int { Calendar.current.component(.hour, from: entry.date) }
    private var greeting: String { hour < 6 || hour >= 22 ? "星光守着你的梦" : (hour < 12 ? "今天，也一起发光" : "忙碌之余，摸摸我吧") }
    var body: some View {
        HStack(spacing: 8) {
            Image("WidgetPet").resizable().scaledToFit().accessibilityLabel("星澜")
            if family == .systemMedium {
                VStack(alignment: .leading, spacing: 12) {
                    Text("星澜").font(.headline).foregroundStyle(Color(red: 0.92, green: 0.76, blue: 0.45))
                    Text(greeting).font(.caption).foregroundStyle(.white.opacity(0.8))
                    HStack {
                        Link(destination: URL(string: "xinglan://feed")!) { Label("喂食", systemImage: "leaf").font(.caption) }
                        Link(destination: URL(string: "xinglan://jump")!) { Label("跳跃", systemImage: "sparkles").font(.caption) }
                    }.foregroundStyle(.white)
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .containerBackground(for: .widget) { Color(red: 0.04, green: 0.08, blue: 0.17) }
        .widgetURL(URL(string: "xinglan://wave"))
    }
}
@main
struct XinglanWidget: Widget {
    let kind = "XinglanCompanion"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PetProvider()) { PetWidgetView(entry: $0) }
            .configurationDisplayName("星澜")
            .description("把星光伙伴放在主屏幕，点击进入互动。")
            .supportedFamilies([.systemSmall, .systemMedium])
            .contentMarginsDisabled()
    }
}
