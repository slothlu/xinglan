import Foundation

final class MockProtocol: URLProtocol {
    static var status = 200
    static var body = Data()
    static var captured: URLRequest?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.captured = request
        let response = HTTPURLResponse(url: request.url!, statusCode: Self.status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: Self.body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main struct APIContractTests {
    static func main() async throws {
        func configuration(_ url: String) -> AIConfiguration { AIConfiguration(address: url, model: "test-model", persona: "test") }
        for (input, expected) in [
            ("https://example.com", "https://example.com/v1/chat/completions"),
            ("https://example.com/v1/", "https://example.com/v1/chat/completions"),
            ("https://example.com/custom/chat/completions", "https://example.com/custom/chat/completions")
        ] {
            let actual = try configuration(input).endpoint().absoluteString
            precondition(actual == expected)
        }
        for invalid in ["http://example.com", "https://user:pass@example.com", "https://example.com?key=secret"] {
            do { _ = try configuration(invalid).endpoint(); fatalError("invalid URL accepted") } catch {}
        }
        let session = URLSessionConfiguration.ephemeral
        session.protocolClasses = [MockProtocol.self]
        let messages = [AIMessage(role: "user", content: "你好")]
        MockProtocol.body = Data(#"{"choices":[{"message":{"content":"你好，星澜在这里。"}}]}"#.utf8)
        let reply = try await AIClient.reply(configuration: configuration("https://example.com/v1"), key: "test-token", messages: messages, sessionConfiguration: session)
        precondition(reply == "你好，星澜在这里。")
        precondition(MockProtocol.captured?.httpMethod == "POST")
        precondition(MockProtocol.captured?.value(forHTTPHeaderField: "Authorization") == "Bearer test-token")
        MockProtocol.status = 401
        do { _ = try await AIClient.reply(configuration: configuration("https://example.com"), key: "", messages: messages, sessionConfiguration: session); fatalError("401 accepted") }
        catch { precondition(error.localizedDescription.contains("401")) }
        MockProtocol.status = 200
        MockProtocol.body = Data(#"{"choices":[]}"#.utf8)
        do { _ = try await AIClient.reply(configuration: configuration("https://example.com"), key: "", messages: messages, sessionConfiguration: session); fatalError("empty choices accepted") } catch {}
        print("API contract checks passed (mock transport; no live API calls).")
    }
}
