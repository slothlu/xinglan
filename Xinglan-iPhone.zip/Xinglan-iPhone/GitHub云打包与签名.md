# GitHub 云打包 → 全能签安装

## 1. 上传源码

在 GitHub 新建仓库，建议选择 Private。将本包解压后，上传 **Xinglan-iPhone 文件夹里面的内容** 到仓库根目录。

根目录应直接包含：

```text
.github/workflows/build-ios.yml
Xinglan.xcodeproj/
App/
Shared/
Widget/
```

注意 `.github` 是隐藏目录，必须一起上传。不要只把源码 ZIP 文件上传到仓库，也不要在根目录外再包一层 `Xinglan-iPhone`。

## 2. 手动运行云构建

打开仓库 → Actions → Build unsigned iPhone IPA → Run workflow。

构建成功后，在该次运行页面底部 Artifacts 下载 `Xinglan-unsigned-IPA`。解压下载的 ZIP，得到 `Xinglan-unsigned.ipa` 和 `SHA256.txt`。

构建在 GitHub 的 macOS 机器上运行，不需要自己的 Mac，也不需要把苹果账号、证书或私钥传给 GitHub。私有仓库的 Actions 额度与计费以自己的 GitHub 账户页面为准。

失败时下载 `Xcode-build-log`，其中的 `xcodebuild.log` 包含具体编译错误。当前工程尚未实际在 GitHub 跑过，不把配置完成视为编译成功。

## 3. 在全能签中签名

将 `Xinglan-unsigned.ipa` 传到 iPhone，导入你使用的全能签版本，再使用你已有且有效的签名证书和匹配的描述文件签名安装。各版本菜单名称可能不同。

本包包含主 App 和 `PlugIns/XinglanWidget.appex` 小组件扩展。**保留扩展，并让签名工具处理主 App 与扩展的签名。** 如果更改主 App Bundle ID，小组件 ID 也必须保持正确的子标识关系，且两者都应被相应签名配置覆盖。

如果签名工具仅能签主 App 或必须删除扩展，App 仍可能安装，但不能使用主屏幕小组件。不要把“删除扩展”当成保留小组件的解决方法。

未签名 IPA 不能直接安装；是否能安装取决于实际证书、描述文件、设备和签名工具对扩展的支持。本工程不附带证书或描述文件。

## 4. 添加小组件

安装后先打开“星澜”一次。长按主屏幕空白处 → 添加小组件 → 搜索“星澜”，选择小号或中号。

App 内播放动画；小组件展示静态形象，点击喂食/跳跃入口打开 App。

## 来源

- GitHub 托管构建机：https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- Actions 额度与计费：https://docs.github.com/en/actions/concepts/billing-and-usage
