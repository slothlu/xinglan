import Foundation

enum PetAction: String, CaseIterable, Identifiable {
    case idle, right, left, wave, jump, failed, waiting, thinking, review
    var id: String { rawValue }
    var row: Int { Self.allCases.firstIndex(of: self)! }
    var frames: Int { [6, 8, 8, 4, 5, 8, 6, 6, 6][row] }
    var title: String { ["休息", "向右跑", "向左跑", "招手", "跳跃", "委屈", "等你", "思考", "观察"][row] }
    var symbol: String { ["moon.stars", "arrow.right", "arrow.left", "hand.wave", "sparkles", "cloud", "heart", "lightbulb", "eye"][row] }
}
