import SwiftUI

@main
struct XinglanApp: App {
    var body: some Scene {
        WindowGroup { PetHome() }
    }
}
