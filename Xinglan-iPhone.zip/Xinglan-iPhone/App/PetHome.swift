import SwiftUI
import UIKit

struct PetHome: View {
    @AppStorage("petName") private var name = "星澜"
    @AppStorage("feedingCount") private var feedings = 0
    @AppStorage("haptics") private var haptics = true
    @State private var action: PetAction = .idle
    @State private var started = Date()
    @State private var reactionID = UUID()
    @State private var message = "在现实与梦想之间，陪你一路前行。"
    @State private var position = CGSize.zero
    @GestureState private var drag = CGSize.zero
    @State private var settings = false
    @State private var lookAround = false
    @State private var gaze = 0.0
    @Environment(\.scenePhase) private var scenePhase
    private let gold = Color(red: 0.92, green: 0.76, blue: 0.45)

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(colors: [Color(red: 0.035, green: 0.06, blue: 0.14), Color(red: 0.10, green: 0.17, blue: 0.29)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 20) {
                        header
                        Text(message).font(.callout).foregroundStyle(.white.opacity(0.8)).multilineTextAlignment(.center).frame(minHeight: 44)
                        ZStack {
                            Circle().fill(.blue.opacity(0.08)).frame(width: 250, height: 250)
                            Circle().stroke(gold.opacity(0.18), lineWidth: 1).frame(width: 270, height: 270)
                            PetSprite(action: drag == .zero ? action : (drag.width < 0 ? .left : .right), started: started, gaze: lookAround ? Int(gaze) : nil)
                                .frame(width: min(geometry.size.width - 80, 300), height: 300)
                                .offset(x: bounded(position.width + drag.width, limit: max(0, (geometry.size.width - 290) / 2)), y: bounded(position.height + drag.height, limit: 24))
                                .contentShape(Rectangle())
                                .onTapGesture { react(.wave, "摸摸头，今天也有我陪你。") }
                                .gesture(DragGesture(minimumDistance: 8).updating($drag) { value, state, _ in state = value.translation }.onEnded { value in
                                    position.width = bounded(position.width + value.translation.width, limit: max(0, (geometry.size.width - 290) / 2))
                                    position.height = bounded(position.height + value.translation.height, limit: 24)
                                    react(.idle, "我在这里。")
                                })
                        }.frame(maxWidth: .infinity).frame(height: 350).clipped()
                        HStack(spacing: 12) {
                            control("喂食", icon: "leaf.fill") { feed() }
                            control("摸摸", icon: "hand.draw.fill") { react(.wave, "收到你的温柔了。") }
                            control("跳一跳", icon: "sparkles") { react(.jump, "向星光，再靠近一点。") }
                        }
                        VStack(alignment: .leading, spacing: 14) {
                            Text("陪伴时刻").font(.headline).foregroundStyle(gold)
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 85))], spacing: 10) {
                                ForEach(PetAction.allCases) { item in
                                    Button { react(item, "\(name) · \(item.title)") } label: {
                                        Label(item.title, systemImage: item.symbol).font(.caption).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    }.buttonStyle(.bordered).tint(action == item ? gold : .white)
                                }
                            }
                            Toggle("看看四周", isOn: $lookAround).tint(gold)
                            if lookAround {
                                Slider(value: $gaze, in: 0...15, step: 1).tint(gold).accessibilityLabel("注视方向")
                                Text("从上方开始，顺时针探索十六个方向").font(.caption).foregroundStyle(.secondary)
                            }
                        }.padding(20).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 24))
                        PetChat { next, text in react(next, text) }
                        Text("已投喂 \(feedings) 次 · 数据保存在这台 iPhone 上")
                            .font(.caption).foregroundStyle(.white.opacity(0.5))
                        Text("主屏幕小组件可快速唤起互动；离开 App 后动画暂停。")
                            .font(.caption).foregroundStyle(.white.opacity(0.5)).multilineTextAlignment(.center)
                    }.padding(24).frame(maxWidth: 600).frame(maxWidth: .infinity)
                }
            }
            .foregroundStyle(.white)
            .sheet(isPresented: $settings) {
                NavigationStack {
                    Form {
                        TextField("宠物名字", text: $name)
                        Toggle("触感反馈", isOn: $haptics)
                        NavigationLink("智能配置") { AISettingsView() }
                        Section("关于桌宠") {
                            Text("动画在 App 内播放，小组件显示静态宠物和快捷入口。此 App 不会悬浮在其他应用上方。")
                            Text("无需 App 账号。智能聊天会把会话内容发送到你配置的服务商；喂食与触摸记录仅保存在本机。")
                        }
                    }.navigationTitle("伙伴设置").toolbar { Button("完成") { settings = false } }
                }.presentationDetents([.medium, .large])
            }
            .onAppear {
                if name == "星澜灵麟" { name = "星澜" }
            }
            .onOpenURL { url in
                guard url.scheme == "xinglan" else { return }
                if url.host == "feed" { feed() }
                else if url.host == "jump" { react(.jump, "一起跳向星光。") }
                else { react(.wave, "你回来啦。") }
            }
            .onChange(of: scenePhase) { _, phase in
                if phase != .active { action = .idle; lookAround = false }
                else { started = Date() }
            }
            .task(id: reactionID) {
                guard action != .idle && action != .thinking else { return }
                do { try await Task.sleep(for: .seconds(action == .jump ? 0.7 : 2.5)) } catch { return }
                action = .idle; started = Date()
            }
        }.preferredColorScheme(.dark)
    }
    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 6) {
                Text("你的星光伙伴").font(.caption).tracking(3).foregroundStyle(gold)
                Text(name.isEmpty ? "星澜" : name).font(.largeTitle.bold())
            }
            Spacer()
            Button { settings = true } label: { Image(systemName: "slider.horizontal.3").padding(12).background(.white.opacity(0.08), in: Circle()) }.accessibilityLabel("设置")
        }
    }
    private func bounded(_ value: CGFloat, limit: CGFloat) -> CGFloat { min(limit, max(-limit, value)) }
    private func control(_ title: String, icon: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) { VStack(spacing: 9) { Image(systemName: icon).font(.title3); Text(title).font(.subheadline) }.frame(maxWidth: .infinity).padding(.vertical, 16).background(gold.opacity(0.12), in: RoundedRectangle(cornerRadius: 18)) }.foregroundStyle(gold)
    }
    private func feed() { feedings += 1; react(.review, "星光点心收到了，第 \(feedings) 次，谢谢你。") }
    private func react(_ next: PetAction, _ text: String) {
        lookAround = false; action = next; started = Date(); message = text; reactionID = UUID()
        if haptics { UIImpactFeedbackGenerator(style: .soft).impactOccurred() }
    }
}
