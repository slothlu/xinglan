import SwiftUI
import UIKit

/// Crops the validated 8 × 11 atlas once; playback never decodes a GIF.
final class SpriteStore {
    static let shared = SpriteStore()
    private let images: [[UIImage]]
    private init() {
        guard let url = Bundle.main.url(forResource: "spritesheet-final", withExtension: "png"),
              let source = UIImage(contentsOfFile: url.path)?.cgImage else {
            images = []; return
        }
        images = (0..<11).map { row in
            (0..<8).map { column in
                guard let crop = source.cropping(to: CGRect(x: column * 192, y: row * 208, width: 192, height: 208)) else { return UIImage() }
                return UIImage(cgImage: crop)
            }
        }
    }
    func image(row: Int, frame: Int) -> UIImage? {
        guard images.indices.contains(row), images[row].indices.contains(frame) else { return nil }
        return images[row][frame]
    }
}

struct PetSprite: View {
    let action: PetAction
    let started: Date
    var gaze: Int? = nil
    @Environment(\.scenePhase) private var phase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        TimelineView(.animation(minimumInterval: 0.14, paused: phase != .active || reduceMotion || gaze != nil)) { context in
            let elapsed = max(0, context.date.timeIntervalSince(started))
            let frame = reduceMotion ? 0 : Int(elapsed / 0.14) % action.frames
            let row = gaze.map { 9 + $0 / 8 } ?? action.row
            if let image = SpriteStore.shared.image(row: row, frame: gaze.map { $0 % 8 } ?? frame) {
                Image(uiImage: image).resizable().scaledToFit()
            } else {
                ContentUnavailableView("素材未加载", systemImage: "photo", description: Text("请确认 spritesheet-final.png 已加入 App 资源。"))
            }
        }
        .accessibilityLabel("星澜，\(action.title)")
    }
}
