import SwiftUI

struct AISettingsView: View {
    @State private var address = AIConfiguration.saved.address
    @State private var model = AIConfiguration.saved.model
    @State private var persona = AIConfiguration.saved.persona
    @State private var key = ""
    @State private var status = ""
    @State private var testing = false
    @State private var task: Task<Void, Never>?
    private var configuration: AIConfiguration { AIConfiguration(address: address, model: model, persona: persona) }
    var body: some View {
        Form {
            Section("通用接口 · Chat Completions") {
                TextField("Base URL，例如 https://api.example.com/v1", text: $address).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                TextField("模型名（按服务商填写）", text: $model).textInputAutocapitalization(.never).autocorrectionDisabled()
                SecureField("API Key（无鉴权服务可留空）", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                Text("可填写 Base URL 或完整 /chat/completions 地址。仅支持 HTTPS、Bearer 鉴权及兼容文本接口；不支持所有厂商的专有协议。").font(.caption)
            }.disabled(testing)
            Section("星澜的性格") { TextEditor(text: $persona).frame(minHeight: 100).disabled(testing) }
            Section {
                Button("保存配置") { save() }.disabled(testing)
                Button(testing ? "正在测试…" : "测试连接（发送一条简短请求）") { test() }.disabled(testing)
                if testing { Button("取消测试") { task?.cancel() } }
                if !status.isEmpty { Text(status).font(.callout).accessibilityLabel(status) }
            }
            Section("数据与密钥") {
                Text("密钥按接口地址分别保存在本机 Keychain。改地址后需重新填写对应密钥。发送聊天时，当前会话最近的内容与角色设定会交给你配置的服务商处理，可能产生 API 费用。")
                Button("删除当前接口的密钥", role: .destructive) {
                    do { try APIKeyStore.save("", endpoint: configuration.endpoint()); key = ""; status = "密钥已删除。" }
                    catch { status = error.localizedDescription }
                }.disabled(testing)
            }
        }.navigationTitle("智能配置")
        .onAppear { loadKey() }
        .onChange(of: address) { _, _ in key = ""; status = "" }
        .onDisappear { task?.cancel() }
    }
    private func loadKey() {
        do { key = try APIKeyStore.read(configuration.endpoint()) } catch { key = "" }
    }
    @discardableResult private func save() -> Bool {
        do {
            let endpoint = try configuration.endpoint()
            guard !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIError.message("请填写模型名。") }
            try APIKeyStore.save(key.trimmingCharacters(in: .whitespacesAndNewlines), endpoint: endpoint)
            let d = UserDefaults.standard
            d.set(address.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "aiAddress")
            d.set(model.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "aiModel")
            d.set(persona, forKey: "aiPersona")
            status = "已保存。"; return true
        } catch { status = error.localizedDescription; return false }
    }
    private func test() {
        guard save() else { return }
        testing = true; status = "正在连接…"
        let config = configuration; let token = key.trimmingCharacters(in: .whitespacesAndNewlines)
        task = Task { @MainActor in
            defer { testing = false }
            do {
                _ = try await AIClient.reply(configuration: config, key: token, messages: [AIMessage(role: "user", content: "请只回复：连接成功")])
                try Task.checkCancellation(); status = "连接成功，已收到模型回复。"
            } catch { status = Task.isCancelled ? "测试已取消。" : error.localizedDescription }
        }
    }
}

struct PetChat: View {
    let onAction: (PetAction, String) -> Void
    @State private var messages: [AIMessage] = []
    @State private var draft = ""
    @State private var busy = false
    @State private var errorText = ""
    @State private var task: Task<Void, Never>?
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("和星澜聊聊", systemImage: "bubble.left.and.bubble.right").font(.headline)
                Spacer()
                Button("清空") { task?.cancel(); messages = []; errorText = "" }.disabled(busy || messages.isEmpty)
            }
            Text("先在设置 → 智能配置填写接口。发送后，当前会话内容会交给该服务商处理。").font(.caption).foregroundStyle(.secondary)
            if !messages.isEmpty {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 12) {
                            ForEach(messages) { item in
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.role == "user" ? "你" : "星澜").font(.caption).foregroundStyle(.secondary)
                                    Text(item.content).textSelection(.enabled)
                                }.frame(maxWidth: .infinity, alignment: .leading).padding(10).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12)).id(item.id)
                            }
                        }
                    }.frame(height: 240)
                    .onChange(of: messages.count) { _, _ in if let last = messages.last { proxy.scrollTo(last.id, anchor: .bottom) } }
                }
            }
            TextField("想和星澜说什么？", text: $draft, axis: .vertical).lineLimit(1...5).textFieldStyle(.roundedBorder).disabled(busy)
            HStack {
                if busy { ProgressView(); Text("星澜正在思考…").font(.caption); Spacer(); Button("取消") { task?.cancel() } }
                else { Button("发送") { send() }.buttonStyle(.borderedProminent).disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
            }
            if !errorText.isEmpty { Text(errorText).font(.caption).foregroundStyle(.orange) }
        }.padding(20).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 24))
        .onDisappear { task?.cancel() }
    }
    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !busy else { return }
        guard text.count <= 4000 else { errorText = "单次消息请控制在 4000 字以内。"; return }
        let config = AIConfiguration.saved
        let key: String
        do { key = try APIKeyStore.read(config.endpoint()) } catch { errorText = "请先在智能配置中保存有效接口。"; return }
        let user = AIMessage(role: "user", content: text)
        let history = Array(messages.suffix(20))
        messages.append(user); draft = ""; busy = true; errorText = ""; onAction(.thinking, "让我想一想…")
        task = Task { @MainActor in
            defer { busy = false }
            do {
                let reply = try await AIClient.reply(configuration: config, key: key, messages: [AIMessage(role: "system", content: config.persona)] + history + [user])
                try Task.checkCancellation()
                messages.append(AIMessage(role: "assistant", content: reply))
                if messages.count > 40 { messages.removeFirst(messages.count - 40) }
                onAction(.wave, "星澜回复你啦。")
            } catch {
                messages.removeAll { $0.id == user.id }
                draft = text
                errorText = Task.isCancelled ? "已取消，可修改后重新发送。" : error.localizedDescription
                onAction(Task.isCancelled ? .idle : .failed, Task.isCancelled ? "我在这里。" : "暂时没连上，稍后再试试。")
            }
        }
    }
}
