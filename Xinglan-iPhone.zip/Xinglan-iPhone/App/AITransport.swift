import Foundation
import Security

struct AIConfiguration {
    var address: String
    var model: String
    var persona: String
    func endpoint() throws -> URL {
        let raw = address.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var parts = URLComponents(string: raw), parts.scheme?.lowercased() == "https",
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil else {
            throw AIError.message("请填写 HTTPS 接口地址，不含账号、查询参数或 # 片段。")
        }
        var path = parts.path
        while path.hasSuffix("/") { path.removeLast() }
        if path.isEmpty { path = "/v1" }
        if !path.hasSuffix("/chat/completions") { path += "/chat/completions" }
        parts.path = path
        guard let url = parts.url else { throw AIError.message("接口地址无效。") }
        return url
    }
    static var saved: AIConfiguration {
        let d = UserDefaults.standard
        return AIConfiguration(address: d.string(forKey: "aiAddress") ?? "", model: d.string(forKey: "aiModel") ?? "", persona: d.string(forKey: "aiPersona") ?? "你叫星澜，是温暖、机灵的灵兽伙伴。用简洁自然的中文回应，不要假装执行现实中没有执行的操作。")
    }
}

enum AIError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}

enum APIKeyStore {
    private static func query(_ endpoint: URL) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "Xinglan.APIKey",
         kSecAttrAccount as String: endpoint.absoluteString]
    }
    static func read(_ endpoint: URL) throws -> String {
        var q = query(endpoint)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &result)
        if status == errSecItemNotFound { return "" }
        guard status == errSecSuccess, let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else {
            throw AIError.message("无法读取钥匙串，请解锁设备后重试。")
        }
        return value
    }
    static func save(_ value: String, endpoint: URL) throws {
        let q = query(endpoint)
        if value.isEmpty {
            let status = SecItemDelete(q as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else { throw AIError.message("删除密钥失败。") }
            return
        }
        let updates: [String: Any] = [kSecValueData as String: Data(value.utf8)]
        var status = SecItemUpdate(q as CFDictionary, updates as CFDictionary)
        if status == errSecItemNotFound {
            var item = q
            item[kSecValueData as String] = Data(value.utf8)
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw AIError.message("保存密钥失败，请检查签名或设备钥匙串。") }
    }
}

// Do not forward a bearer token to a redirect destination.
final class NoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

struct AIMessage: Codable, Identifiable {
    var id = UUID()
    let role: String
    let content: String
    enum CodingKeys: String, CodingKey { case role, content }
}

enum AIClient {
    static func reply(configuration: AIConfiguration, key: String, messages: [AIMessage], sessionConfiguration: URLSessionConfiguration = .ephemeral) async throws -> String {
        let endpoint = try configuration.endpoint()
        let model = configuration.model.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !model.isEmpty else { throw AIError.message("请先填写模型名。") }
        struct Body: Encodable { let model: String; let messages: [AIMessage]; let stream = false }
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !key.isEmpty { request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try JSONEncoder().encode(Body(model: model, messages: messages))
        let settings = sessionConfiguration
        settings.timeoutIntervalForResource = 75
        let session = URLSession(configuration: settings, delegate: NoRedirects(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw AIError.message("没有收到有效 HTTP 响应。") }
        guard (200...299).contains(http.statusCode) else {
            let hint: String
            switch http.statusCode {
            case 301...399: hint = "接口发生重定向，请填写最终接口地址。"
            case 401, 403: hint = "密钥无效或没有模型权限。"
            case 404: hint = "检查接口路径和模型名。"
            case 429: hint = "请求过多或服务额度不足，请稍后重试。"
            case 500...599: hint = "服务暂时不可用，请稍后重试。"
            default: hint = "检查服务商的兼容格式、模型和请求设置。"
            }
            throw AIError.message("HTTP \(http.statusCode)：\(hint)")
        }
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = root["choices"] as? [[String: Any]],
              let message = choices.first?["message"] as? [String: Any] else {
            throw AIError.message("响应不是兼容 Chat Completions 的格式。")
        }
        let text: String
        if let content = message["content"] as? String { text = content }
        else if let parts = message["content"] as? [[String: Any]] { text = parts.compactMap { $0["text"] as? String }.joined(separator: "\n") }
        else if let refusal = message["refusal"] as? String { text = refusal }
        else { text = "" }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIError.message("模型没有返回可显示的文字，请检查模型是否支持文本聊天。") }
        return text
    }
}

